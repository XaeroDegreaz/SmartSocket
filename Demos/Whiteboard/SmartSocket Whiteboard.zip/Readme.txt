This is something I put together after a couple hours (most of the time was spent tweaking the actual SmartSocket server ;) ), and should not be taken as the de-facto standard of how the server performs.

This is a very rough go of the use of the protocol, but it's still very effective.

Simply launch the JAR then you and a few buddies launch the SWF and put in the address the server is running on (demos.smartsocket.net may or may not be running at any given time, and you may need to create a projector out of it if your Flash Player security is high).

-Jerome